<?php

namespace App\Http\Controllers;
use DB;
use Cart;
use App\placetb;
use App\logintb;
use App\registertb;
use App\producttb;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\storage;
use Illuminate\Support\Facades\Session;
class vegcontroller extends Controller
{
    public function login_show()
    {
        return view('login');
    }
    public function register_show()
    {
        return view('register');
    }
     public function addtable()
    {
        return view('add');
    }
    public function change_pwd()
    {
        return view('changepwd');
    }
    
    public function place_show()
    {
        return view('addplace');
    }
     public function add_places(Request $request)
    {
        $place = new placetb();
        $place-> name = $request->input('place_name');
        $place->save();
        return view('/addplace');
    }
public function place_list(Request $request){
        $pl_data = placetb::all();
    return view('/register')->with('pl_data',$pl_data);
}

public function register(Request $request)
    {
        $login = new logintb();
        $login-> user_name = $request->input('userid');
        $login-> password = $request->input('pwd');
        $login-> role = 'user';
        $login->save();

        $reg = new registertb();
        $reg-> f_name = $request->input('fname');
        $reg-> l_name = $request->input('lname');
        $reg-> fk_login_id = $login-> id;
        $reg-> address = $request->input('addres');
        $reg-> place = $request->input('pname');
        $reg-> zip = $request->input('zipcode');
        $reg->save();
        return view('/register');
    }


public function login_fun(Request $request) {
 
        $uname = $request->input('mail');
        $pwd = $request->input('password');
       
        $con = DB::table('login')->where('user_name', $uname)->first();

        if (is_null($con)) {
            return view('/register');
        } else {
            if ($con -> password == $pwd) {
                $request->session()->put('userId', $con -> id);
                if ($con -> role == 'admin') {
                    return view('/admin');
                } else {
                    return view('/ui');
                }
            } else {
                return view('login');
            }
        }
       
    }

    public function change_password(Request $request){
        $id = $request->session()->get('userId');
        $user = logintb::find($id);                
        $user-> password = $request->input('confirmpwd');
        $user->save();               
        return view('/changepwd');
        }
    public function add_item(Request $request){
        $item = new producttb();
        $item-> item_name = $request->input('itemname');
        $item-> category = $request->input('category');
        // $item-> item_name = $request->input('itemname');
        $item-> no_of_stock = $request->input('stock');
    if ($request->hasfile('image')){
            $file = $request->file('image');
            $extension = time().'.'.$file->getClientOriginalExtension();
            $destinationpath = public_path('/images');
            $file->move($destinationpath, $extension);
            $item->image = $extension; 
        }
        else{
            $item->image ='';
        }
            $item-> price = $request->input('price');
            $item->save();
        return view('/add');
    }
    
    
    public function view_data(Request $request){
        $view = producttb::all();
        return view('/view')->with('view',$view);
    } 

    public function data_show($id){
        $edit = producttb::find($id);
        return view('/editdata')->with('edit',$edit);       
}
public function update_datas(Request $request){
        $id= $request->input('id');
        $edit = producttb::find($id);
        $edit-> item_name= $request->input('itemname');
        $edit-> category= $request->input('category');
        $edit-> no_of_stock= $request->input('stock');
        if ($request->hasfile('image')){
            $file = $request->file('image');
            $extension = time().'.'.$file->getClientOriginalExtension();
            $destinationpath = public_path('/images');
            $file->move($destinationpath, $extension);
            $edit->image=$extension; 
            
        }
        else{
            $edit->image='';
        }
        $edit-> price = $request->input('price');
        $edit->save();
        return redirect('/view')->with('edit',$edit);
    }

    public function delete_fn($id){
        $item = producttb::find($id);
        $item->delete();
        return Redirect()->back();
    }

    public function product_list(){
        // echo "hii";
        // exit;
        $product_data = producttb::all();
        //var_dump($product_data);
        //exit;
    return view('/all_veg')->with('product_data',$product_data);
}
  public function addedcart(Request $request, $id){

     $product = producttb::find($id);
       // session()->put('item',$item-> item_name;
       //  session()->put('price',$price-> price;
 //       //      var_dump(item);
 //        // $product_data-> = $request->input('unit');
        
 //        // return view('/all_veg')->with('product_data',$product_data);
    $cart = Session::get('cart');
    
            Cart::add ([
                        "name" => $product->item_name,
                        "quantity" => 1,
                        "price" => $product->price,
                        "photo" => $product->image
                    ]);
 
            session()->put('cart', $cart);

            var_dump($cart);
            exit;
 
            return redirect('/cart_show');
        }
     
     public function cartshow(){
        // echo "hii";
        // exit;
        $cartproducts = Cart::content();
        //var_dump($product_data);
        //exit;
    return view('/cart')->with('cartproducts',$cartproducts);
     
}

}


<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class placetb extends Model
{
    protected $table='place';
    protected $fillable=['id','name',];
}

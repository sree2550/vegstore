<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"
        integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
    	<div style="background-image: url('images/bg_1.jpg');">
            </div>
    		<table class="table">
    			<thead>
           <tr>
               <td>Roll No</td>
               <td>Item Name</td>
               <td>Image</td>
               <td>Quantity</td>
               <td>Rate</td>
               <td>Total</td>
           </tr>         
                </thead>
                <tbody>
                    
            <tr>
              @foreach($cartproducts as $cartproducts)
                <td>{{$cartproducts->item_name}}</td>
                <td>{{$cartproducts->image}}</td>
                <td>{{$cartproducts->price}}<</td>
            </tr>
            @endforeach
                </tbody>
    		</table>
    	
    </div>

</body>
</html>
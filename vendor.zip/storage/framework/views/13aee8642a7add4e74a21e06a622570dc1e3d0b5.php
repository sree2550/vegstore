<?php $__env->startSection('content'); ?>

<h1><b>Add Items</b></h1>
<form action="<?php echo e(url ('editdetails')); ?>" method="POST" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <input type="hidden" name="id" value="<?php echo e($edit->item_id); ?>">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="row">
    <div class="form-group">
      <label for="email" class="control-label">Item Name</label>
      <input type="text" class="form-control" name="itemname" value="<?php echo e($edit->item_name); ?>">
    </div>
    <div class="form-group">
      <label for="pwd" class="control-label">Category</label>
      <input type="text" class="form-control" name="category" value="<?php echo e($edit->category); ?>">
    </div>
     <div class="form-group">
      <label for="pwd" class="control-label">Number of Items In Stock</label>
      <input type="text" class="form-control" name="stock" value="<?php echo e($edit->no_of_stock); ?>">
    </div>
    <div class="form-group">
    <label for="exampleFormControlFile1">Image</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="image" value="<?php echo e($edit->image); ?>">
  </div>
    <div class="col">
    <label for="pwd">Price per 100 gram</label>
    <input type="text" class="form-control" name="price" value="<?php echo e($edit->price); ?>">
    </div><br>
     <div>
  <button type="submit" class="btn btn-success">Submit</button>
  </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\heroku\online_shop\resources\views//editdata.blade.php ENDPATH**/ ?>
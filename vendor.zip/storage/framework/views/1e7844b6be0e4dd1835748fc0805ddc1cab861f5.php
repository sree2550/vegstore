<?php $__env->startSection('content'); ?>
<div class="col-xs-4">
	<h1><b>Add Place</b></h1>
	<form action="<?php echo e(url('addplace')); ?>" method="post">
  <div class="form-group">
    <label for="email">Name of Place</label>
    <input type="text" class="form-control" id="email" name="place_name">
  </div>
  <button type="submit" class="btn btn-success">Submit</button>
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\heroku\online_shop\resources\views/add_place.blade.php ENDPATH**/ ?>
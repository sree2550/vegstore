<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('update')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

<div class="container">            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Item Name</th>
        <th>Category</th>
        <th>No of stock in kg</th>
        <th>image</th>
        <th>Price</th>
        <th>edit</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($show->item_name); ?></td>
        <td><?php echo e($show->category); ?></td>
        <td><?php echo e($show->no_of_stock); ?></td>
        <td><img src="<?php echo e(asset('images/'.$show->image)); ?>" width="100px" height="100px"></td>
        <td><?php echo e($show->price); ?></td>
       <!--  <td><a href="<?php echo e(URL::to('edit/'.$show->id)); ?>" class="btn btn-info" role="button"> edit</a></td> -->
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\heroku\online_shop\resources\views/update.blade.php ENDPATH**/ ?>